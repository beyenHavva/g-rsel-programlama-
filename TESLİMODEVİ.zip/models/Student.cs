﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Student : Person
    {
        private int studentID;
        private string programName;
        private string coureName;

        public Student()
        {

        }

        public Student(int personID, string firstName, string lastName,
           string gender, string email, string password, int age, int studentID,
           string programName, string coureName)
           : base(personID, firstName, lastName, gender, email, password, age)
        {
            this.StudentID = studentID;
            this.ProgramName = programName;
            this.CoureName = coureName;
        }

        public int StudentID { get => studentID; set => studentID = value; }
        public string ProgramName { get => programName; set => programName = value; }
        public string CoureName { get => coureName; set => coureName = value; }


        //public void Display()
        //{
        //    Console.WriteLine($"ID = {studentID} \tName = {FirstName} {LastName}\t Department = {DepartmentID}");
        //}

        //override
        public override void ViewNotification()
        {
            Console.WriteLine("Student Notification method person.");
            //base.ViewNotification();
        }

        public override Person login(string email, string password)
        {
            
            try
            {
                string query = $"select * from Student where email ='{email}' AND Password='{password}'";
                DataTable dt = dbHelper.ExecuteQuery(query);

                if (dt.Rows.Count > 0)
                {
                    Student std = new Student();
                    std.FirstName = dt.Rows[0]["FirstName"].ToString();
                    std.LastName = dt.Rows[0]["LastName"].ToString();
                    std.Email = dt.Rows[0]["Email"].ToString();
                    return std;
                }
                return null;
            }
            catch (Exception )
            {
                throw new Exception("Error in Login.");
            }
            
        }



        public DataTable GetAllStudent()
        {
            SqlConnection connection = null;

            try
            {
                string conString = "Server=DESKTOP-1U3HFQE;Database=SMSBIM;Trusted_Connection=True;";
                connection = new SqlConnection(conString);
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string query = "select * from Student ";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    return dt;

                }
                return null;

            }
            catch (Exception)
            {
                throw new Exception("Error in login method.");
            }
            finally
            {
                connection.Close();
            }


        }
    }
}
