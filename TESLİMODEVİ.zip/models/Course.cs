﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Course : Lesson
    {
        private string courseName;
        private DateTime courseTime;

        public string CourseName
        {
            get => courseName;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("Course name is empty.");
                }

                courseName = value;
            }

        }
        public DateTime CourseTime { get => courseTime; set => courseTime = value; }

        //public DataTable GetAllCourse()
        //{
        //    try
        //    {
        //        string query = "select * from Course";
        //        return dbHelper.ExecuteQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in GetAllCourse.");
        //    }
        //}

        //public DataTable GetAllCourseTopN(int N)
        //{
        //    try
        //    {
        //        string query = $"select TOP({N}) * from Course order by  Name";
        //        return dbHelper.ExecuteQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in GetAllCourseTopN.");
        //    }
        //}

        //public int GetAllCourseCount()
        //{
        //    try
        //    {
        //        string query = $"select COUNT(CourseID) Courses from Course";
        //        return int.Parse(dbHelper.ExecuteQuery(query).Rows[0][0].ToString());
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in GetAllCourseTopN.");
        //    }
        //}

        //public DataTable GetCourseByID(int id)
        //{
        //    try
        //    {
        //        string query = $"select * from Course where CourseID = {id}";
        //        return dbHelper.ExecuteQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in Login.");
        //    }

        //}

        //public DataTable GetCourseByName(string name)
        //{
        //    try
        //    {
        //        string query = $"select * from Course where Name LIKE '%{name}%' order by Name ";
        //        return dbHelper.ExecuteQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in Login.");
        //    }
        //}

        //private static bool CourseExists(string name)
        //{
        //    try
        //    {
        //        string query = $"select * from Course where Name = '{name}'";
        //        return dbHelper.ExecuteQuery(query).Rows.Count >= 1;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in Login.");
        //    }
        //}


        //public int CourseAdd(Course c)
        //{
        //    try
        //    {
        //        if (CourseExists(c.Name))
        //        {
        //            throw new Exception("Course already exists.");
        //        }
        //        string query = $"INSERT INTO Course(Name, Credit) VALUES('{c.Name}',{c.Credit})";
        //        return dbHelper.ExecuteNonQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}


        //public int CourseUpdate(Course c)
        //{
        //    try
        //    {
        //        string query = $"UPDATE Course SET Name = '{c.Name}', Credit = {c.Credit} " +
        //            $"WHERE CourseID = {c.CourseID}";
        //        return dbHelper.ExecuteNonQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in Login.");
        //    }
        //}


        //public int CourseDelete(int cID)
        //{
        //    try
        //    {
        //        string query = $"DELETE Course WHERE CourseID={cID}";
        //        return dbHelper.ExecuteNonQuery(query);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}


        public Course(string lessonName, int lessonKredi, DateTime lessonTime,
           string firstName, string lastName, string classAddress,
           string courseName, DateTime courseTime)
           : base(lessonName, lessonKredi, lessonTime, firstName, lastName, classAddress)
        {
            this.CourseName = courseName;
            this.CourseTime = courseTime;
        }
    }
}
