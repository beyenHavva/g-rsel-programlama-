﻿using System;

namespace son.model
{
    public abstract class Person
    {
        private int personID;
        private string firstName;
        private string lastName;
        private string gender;
        private string email;
        private string password;
        private int age;

        public Person()
        {
            //Console.WriteLine("In Person Constructor.");
        }
        public string Name
        {
            get { return firstName + " " + lastName; }
        }

        public int PersonID { get => personID; set => personID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Email { get => email; set => email = value; }
        public string Password { get => password; set => password = value; }
        public int Age { get => age; set => age = value; }

        

        public Person(int personID, string firstName, string lastName,
           string gender, string email, string password, int age)
        {
            this.PersonID = personID;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Gender = gender;
            this.Email = email;
            this.Password = password;
            this.Age = age;
        }

        public abstract Person login(string email, string password);
  
       

        public virtual void ViewNotification()
        {
            Console.WriteLine("Notification method person.");
        }

        public void Logout(Person p)
        {
            try
            {
                if (p is Employee)
                {
                    Console.WriteLine("Employee Logout Successfully."+ $"Thank you {p.firstName}.");

                }
                else
                {
                    if (p is Student)
                    {
                        Console.WriteLine("Student Logout Successfully."+ $"Thank you {p.firstName}.");

                    }
                    else
                    {
                        Console.WriteLine("Person Logout Successfully."+ $"Thank you {p.firstName}.");
                    }
                }
            }
            catch (Exception)
            {
                throw new Exception("Error in login method.");
            }
        }
        
       
   }

}
