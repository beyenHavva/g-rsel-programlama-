﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son
    .model

{
    public class Attendence : Lesson
    {
        private int personID;

        
        public int PersonID { get => personID; set => personID = value; }

        public Attendence(string lessonName, int lessonKredi,
            string firstName, string lastName, string classAddress,
            DateTime lessonTime, int personID)
            : base(lessonName, lessonKredi, lessonTime, firstName, lastName,
                  classAddress)
        {
            this.PersonID = personID;
        }

    }
}
