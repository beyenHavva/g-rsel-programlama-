﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Register
    {
        private int personID;
        private string courseName;

        //public int PersonID { get => personID; set => personID = value; }
        //public string CourseName { get => courseName; set => courseName = value; }

        public Register(int personID, string courseName)
        {
            this.personID = personID;
            this.courseName = courseName;
        }
    }
}
