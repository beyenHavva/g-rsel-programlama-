﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Program1 : Lesson
    {

        private string programName;
        private string abbreviation;

        public Program1()
        {

        }

        public Program1(string lessonName, int lessonKredi, DateTime lessonTime,
            string firstName, string lastName, string classAddress,
            string programName, string abbreviation)
            :base(lessonName,lessonKredi,lessonTime,firstName,lastName,classAddress)
        {
            this.programName = programName;
            this.abbreviation = abbreviation;
        }

        //public void Display()
        //{
        //    Console.WriteLine($"ID = {departmentID}, Name  = {name}");
        //}

        //public int GetAllDepartmentCount()
        //{
        //    try
        //    {
        //        string query = $"select COUNT(DepartmentID) Department from Department";
        //        return int.Parse(dbHelper.ExecuteQuery(query).Rows[0][0].ToString());
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error in GetAllCourseTopN.");
        //    }
        //}


        public DataTable GetAllProgram()
        {
            SqlConnection connection = null;
            try
            {
                string conString = "Server=YUK-5CD8282ZY6;Database=SMSBIM;Trusted_Connection=True;";
                connection = new SqlConnection(conString);
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string query = "select * from Program";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;

                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public void AddProgram1(Program1 P)
        {

        }
        public void AddProgram1(string programName,string abbreviation)
        {

        }
    }
}
