﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Employee : Person
    {
        private string departmentName;
        private float salary;
        byte[] picture;
        private string serviceName;

        public Employee() 
        { 
        
        }
        
           

        public Employee(int personID, string firstName, string lastName,
            string gender, string email, string password, int age,
            string departmentName, float salary, string serviceName)
            : base(personID, firstName, lastName, gender, email, password, age)
        {
            this.DepartmentName = departmentName;
            this.Salary = salary;
            this.ServiceName = serviceName;
        }

        public string DepartmentName { get => departmentName; set => departmentName = value; }
        public float Salary { get => salary; set => salary = value; }
        public string ServiceName { get => serviceName; set => serviceName = value; }
        public byte[] Picture { get => picture; set => picture = value; }


        //public override void ViewNotification()
        //{
        //    Console.WriteLine("Employee Notification method person.");
        //    //base.ViewNotification();
        //}


        public override Person login(string email, string password)
        {
                try
                {
                    string query = $"select * from Student where email ='{email}' AND Password='{password}'";
                    DataTable dt = dbHelper.ExecuteQuery(query);

                    if (dt.Rows.Count > 0)
                    {
                        Student std = new Student();
                        std.FirstName = dt.Rows[0]["FirstName"].ToString();
                        std.LastName = dt.Rows[0]["LastName"].ToString();
                        std.Email = dt.Rows[0]["Email"].ToString();
                        return std;
                    }
                    return null;
                }
                catch (Exception)
                {
                    throw new Exception("Error in Login.");
                }

        }


        public DataTable GetAllEmployee()
        {
            SqlConnection connection = null;

            try
            {
                string conString = "Server=DESKTOP-1U3HFQE;Database=SMSBIM;Trusted_Connection=True;";
                connection = new SqlConnection(conString);
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string query = "select * from Employee ";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    return dt;

                }
                return null;

            }
            catch (Exception)
            {
                throw new Exception("Error in login method.");
            }
            finally
            {
                connection.Close();
            }


        }

        //public int EmployeeAdd(Employee emp)
        //{
        //    try
        //    {
        //        string query = "INSERT INTO Employee(FirstName,LastName,Email,Password,Salary,Gender,DepartmentID,Picture)" +
        //            "VALUES(@FirstName,@LastName,@Email,@Password,@Salary,@Gender,@DepartmentID,@Picture)";

        //        SqlParameter[] parameters = new SqlParameter[8];

        //        parameters[0] = new SqlParameter("@FirstName", SqlDbType.VarChar, 50);
        //        parameters[0].Value = emp.FirstName;

        //        parameters[1] = new SqlParameter("@LastName", SqlDbType.VarChar, 50);
        //        parameters[1].Value = emp.LastName;

        //        parameters[2] = new SqlParameter("@Email", SqlDbType.VarChar, 50);
        //        parameters[2].Value = emp.Email;

        //        parameters[3] = new SqlParameter("@Password", SqlDbType.VarChar, 50);
        //        parameters[3].Value = emp.Password;

        //        parameters[4] = new SqlParameter("@Salary", SqlDbType.Float);
        //        parameters[4].Value = emp.Salary;

        //        parameters[5] = new SqlParameter("@Gender", SqlDbType.VarChar, 50);
        //        parameters[5].Value = emp.Gender;

        //        parameters[6] = new SqlParameter("@DepartmentID", SqlDbType.Int);
        //        parameters[6].Value = emp.DepartmentID;

        //        parameters[7] = new SqlParameter("@Picture", SqlDbType.Image);
        //        parameters[7].Value = emp.Picture;

        //        return dbHelper.ExecuteNonQuery(query, parameters);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }

        //}


    }
}
