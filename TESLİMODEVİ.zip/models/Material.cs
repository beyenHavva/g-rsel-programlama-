﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Material : Lesson
    {
        private string firstName; // teacher
        private string lastName;

        

        public string FirstName1 { get => firstName; set => firstName = value; }
        public string LastName1 { get => lastName; set => lastName = value; }

        public Material(string lessonName, int lessonKredi, DateTime lessonTime,
             string classAddress, string firstName, string lastName)
            : base(lessonName, lessonKredi, lessonTime, firstName, lastName, 
                  classAddress)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
        }
    }
}
