﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model

{
    public abstract class Calendar
    {
        private DateTime lessonTime;
        private DateTime courseTime;
        private DateTime eventTime;
        private DateTime activityTime;

       

        public DateTime LessonTime { get => lessonTime; set => lessonTime = value; }
        public DateTime CourseTime { get => courseTime; set => courseTime = value; }
        public DateTime EventTime { get => eventTime; set => eventTime = value; }
        public DateTime ActivityTime { get => activityTime; set => activityTime = value; }

        public Calendar(DateTime lessonTime, DateTime courseTime,
           DateTime eventTime, DateTime activityTime)
        {
            this.LessonTime = lessonTime;
            this.CourseTime = courseTime;
            this.EventTime = eventTime;
            this.ActivityTime = activityTime;
        }

    }
}
