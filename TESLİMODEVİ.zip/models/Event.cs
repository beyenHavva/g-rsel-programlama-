﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Event : Calendar
    {
        private string eventName;
        private string activityName;
        private string activityTybe;

        

        public string EventName { get => eventName; set => eventName = value; }
        public string ActivityName { get => activityName; set => activityName = value; }
        public string ActivityTybe { get => activityTybe; set => activityTybe = value; }

        public Event(DateTime lessonTime, DateTime courseTime,
           DateTime eventTime, DateTime activityTime, string eventName,
           string activityName, string activityTybe)
            : base(lessonTime, courseTime, eventTime, activityTime)
        {
            this.EventName = eventName;
            this.ActivityName = activityName;
            this.ActivityTybe = activityTybe;
        }
    }
}
