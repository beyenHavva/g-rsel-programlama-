﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.IdentityModel.Protocols;

namespace son.model
{
    public static class dbHelper
    {
        //// select 
        public static DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            SqlConnection connection = null;
            try
            {
                string conString = "Server=DESKTOP-1U3HFQE;Database=SMSBIM;Trusted_Connection=True;";
                //string conString = ConfigurationManager.AppSettings["constring"].ToString();

                connection = new SqlConnection(conString);
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        // delete update or insert
        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            SqlConnection connection = null;
            try
            {
                string conString = "Server=DESKTOP-1U3HFQE;Database=SMSBIM;Trusted_Connection=True;";
                //string conString = ConfigurationManager.AppSettings["constring"].ToString();
                connection = new SqlConnection(conString);
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    return command.ExecuteNonQuery();
                }
                else
                {
                    throw new Exception("Unable to execute query.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}