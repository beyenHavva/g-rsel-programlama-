﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Teacher : Employee
    {
        private string lessonName;

        public Teacher()
        {

        }

        public Teacher(int personID, string firstName, string lastName,string gender,
            string email, string password, int age,string departmentName, float salary,
            string serviceName,string lessonName) 
            :base(personID,firstName,lastName,gender,email, password ,age,
                 departmentName,salary,serviceName)

        { 
            this.LessonName = lessonName;
        }
        public string LessonName { get => lessonName; set => lessonName = value; }


        //public override void ViewNotification()
        //{
        //    Console.WriteLine("Teacher Notification method person.");
        //    //base.ViewNotification();
        //}

        public override Person login(string email, string password)
        {
            try
            {
                string query = $"select * from Teacher where email ='{email}' AND Password='{password}'";
                DataTable dt = dbHelper.ExecuteQuery(query);

                if (dt.Rows.Count > 0)
                {
                    Teacher tch = new Teacher();

                    tch.FirstName = dt.Rows[0]["FirstName"].ToString();
                    tch.LastName = dt.Rows[0]["LastName"].ToString();
                    tch.Email = dt.Rows[0]["Email"].ToString();
                    return tch;
                }
                return null;
            }
            catch (Exception)
            {
                throw new Exception("Error in login method.");
            }
        }

            public DataTable GetAllTeacher()
            {
            
                SqlConnection connection = null;

                 try
                 {
                      string conString = "Server=DESKTOP-1U3HFQE;Database=SMSBIM;Trusted_Connection=True;";
                      connection = new SqlConnection(conString);
                      connection.Open();

                      if (connection.State == System.Data.ConnectionState.Open)
                      {
                               string query = "select * from Teacher ";
                               SqlCommand command = new SqlCommand(query, connection);
                               SqlDataAdapter adapter = new SqlDataAdapter(command);
                               DataTable dt = new DataTable();
                               adapter.Fill(dt);

                               return dt;

                      }
                      return null;

                 }
                 catch (Exception)
                 {
                 throw new Exception("Error in login method.");
                 }
                 finally
                 {
                 connection.Close();
                 }

        }

    }
}
