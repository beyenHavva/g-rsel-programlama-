﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public class Resources : Service
    {
        private string resourcesName;
        private string bookName;
        private string bookAutherName;
        private int bookPageNumber;
        private string subjectName;
        private string subjectTybe;

        public string ResourcesName { get => resourcesName; set => resourcesName = value; }
        public string BookName { get => bookName; set => bookName = value; }
        public string BookAutherName { get => bookAutherName; set => bookAutherName = value; }
        public int BookPageNumber { get => bookPageNumber; set => bookPageNumber = value; }
        public string SubjectName { get => subjectName; set => subjectName = value; }
        public string SubjectTybe { get => subjectTybe; set => subjectTybe = value; }

        public Resources(string serviceName, string serviceTybe,
            int personID, string firstName, string lastName,
            string resourcesName, string bookName, string bookAutherName,
            int bookPageNumber, string subjectName, string subjectTybe)
            : base(serviceName,serviceName,personID,firstName,lastName)
        {
            this.ResourcesName = resourcesName;
            this.BookName = bookName;
            this.BookAutherName = bookAutherName;
            this.BookPageNumber = bookPageNumber;
            this.SubjectName = subjectName;
            this.SubjectTybe = subjectTybe;
        }
    }
}
