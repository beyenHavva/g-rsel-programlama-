﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model

{
    public abstract class Lesson
    {
        private string lessonName;
        private int lessonKredi;
        private DateTime lessonTime;
        private string firstName;
        private string lastName;
        private string classAddress;

        public Lesson()
        {
            //Console.WriteLine("In Person Constructor.");
        }

        public string LessonName { get => lessonName; set => lessonName = value; }
        public int LessonKredi 
        {
            get => lessonKredi;

            set
            {
                if (value < 0)
                {
                    throw new Exception("Lesson credit cannot be negative.");
                }
                lessonKredi = value;
            }
        }
        public DateTime LessonTime { get => lessonTime; set => lessonTime = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string ClassAddress { get => classAddress; set => classAddress = value; }

        public Lesson(string lessonName, int lessonKredi, DateTime lessonTime,
            string firstName, string lastName, string classAddress)
        {
            this.LessonName = lessonName;
            this.LessonKredi = lessonKredi;
            this.LessonTime = lessonTime;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.ClassAddress = classAddress;
        }
    }
}
