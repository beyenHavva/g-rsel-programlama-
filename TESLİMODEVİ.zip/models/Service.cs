﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace son.model
{
    public abstract class Service
    {
        private string serviceName;
        private string serviceTybe;
        private int personID;
        private string firstName;
        private string lastName;

       

        public string ServiceName { get => serviceName; set => serviceName = value; }
        public string ServiceTybe { get => serviceTybe; set => serviceTybe = value; }
        public int PersonID { get => personID; set => personID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }

        public Service(string serviceName, string serviceTybe,
           int personID, string firstName, string lastName)
        {
            this.ServiceName = serviceName;
            this.ServiceTybe = serviceTybe;
            this.PersonID = personID;
            this.FirstName = firstName;
            this.LastName = lastName;
        }
    }
}
